les scripts sql sont �crits de sorte que les fichiers html 
s'enregistrent dans un dossier 'olvoyage' situ� sur le disque C.